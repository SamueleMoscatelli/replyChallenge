package replyChallenge;

public class ProjectManager extends Worker{

	
	
	public ProjectManager(String company, int bonus, String pos) {
		super(company,bonus,pos);
	}
	

	

	
}
